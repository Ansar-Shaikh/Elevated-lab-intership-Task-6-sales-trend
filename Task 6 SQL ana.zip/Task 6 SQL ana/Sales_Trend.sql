create database task6sql;
use task6sql;

select * from orders;


# .Use EXTRACT(MONTH FROM order_date) for month
select order_date ,sum(amount) from orders group by 1;  


# c.Use SUM() for revenue.
select order_date ,sum(amount) from orders group by 1;


# GROUP BY year/month.
select order_id,month(order_date)  from orders where month(order_date) = 9 group by 1 ;  

# COUNT(DISTINCT order_id) for volume.
select COUNT(DISTINCT order_id) from orders;  # number of  unique customer found 

# Use ORDER BY for sorting
select *  from orders order by amount desc;   # amount col sort by desecending 


select *  from orders order by amount desc limit 1,1;   # second number 

select *  from orders order by amount desc limit 1,3;   #  except first one other three number

